data_path = '/nfs/mar/scratch/data/SensEye/EyeTrack/ction_videos/russ_long_training_2'
X=load([data_path, '/labels_matlab.txt'])
Instances = X(:,1)';
y=X(:,2);
N=length(y);
res = [112,112]

X=ones(N,prod(res)+1);
j=1;
for i=Instances
  img = imread(sprintf('%s/russ_long_training_2_%06d.bmp',data_path,i)) ;
  img = img(:,1:res(2));
  X(j,1:prod(res)) = img(:)';
  j=j+1;
end

save('eye_data.mat','y','X');