function [edges] = UGM_getEdges(n,edgeStruct)
edges = edgeStruct.E(edgeStruct.V(n):edgeStruct.V(n+1)-1);
