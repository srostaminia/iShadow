function [x,y] = nn_predict(img,Mask,Wih,Bh,Who,Bo,K,T,D);

%Compute Hidden Layer Activations
Ah = Bh/255; %Initialize hidden layer activations to hidden layer biases          
for i=1:D
  row = Mask(i,1); %row number 
  col = Mask(i,2); %column number
  x = img(row,col)/255; %image value at (row,col)
  for k=1:K
    Ah(k) = Ah(k) + x*Wih(i,k); %Multiply image value by weight
  end
end


%Compute Hidden layer values and output
x=Bo(1); %Horizontal position
y=Bo(2); %Vertical position
for k=1:K
  h(k) = tanh(Ah(k)); %Apply non-linearity to activations
  x    = x + Who(k,1)*h(k); %accumulate x prediction
  y    = y + Who(k,2)*h(k); %accumulate y prediction
end
x=x*112;
y=y*112;

